/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].use[2]!./src/popup/popup.css":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].use[2]!./src/popup/popup.css ***!
  \*********************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "body {\r\n    height: 400px;\r\n    width: 400px;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/popup.css"],"names":[],"mappings":"AAAA;IACI,aAAa;IACb,YAAY;AAChB","sourcesContent":["body {\r\n    height: 400px;\r\n    width: 400px;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/popup/popup.css":
/*!*****************************!*\
  !*** ./src/popup/popup.css ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_popup_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].use[1]!../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].use[2]!./popup.css */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].use[2]!./src/popup/popup.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_popup_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_popup_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_popup_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_use_2_popup_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/calculations/ActuarialCalculation.ts":
/*!**************************************************!*\
  !*** ./src/calculations/ActuarialCalculation.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const ActuarialCalculation = (interest, payPeriods, gender, payment, smokingStatus, age) => {
    const discountRateArray = [];
    const paymentArray = [];
    // Step 1: Build the discount rate array using n=1,...,payPeriods (1/(1+i)^n)
    let discountRate = 1 / (1 + interest);
    for (let i = 0; i < payPeriods; i++) {
        discountRateArray.push(discountRate);
        discountRate *= 1 / (1 + interest);
    }
    const femaleNonsmokerMortalityArray = [
        0.00032, 0.00035, 0.00038, 0.00041, 0.00043, 0.00044, 0.00044, 0.00045,
        0.00045, 0.00046, 0.00046, 0.00047, 0.00048, 0.00049, 0.0005, 0.00052,
        0.00053, 0.00055, 0.00057, 0.00061, 0.00064, 0.0007, 0.00078, 0.00087,
        0.00098, 0.0011, 0.00124, 0.00138, 0.00152, 0.00166, 0.0018, 0.00196,
        0.00213, 0.00231, 0.0025, 0.00273, 0.00298, 0.00326, 0.00359, 0.00393,
        0.0043, 0.00467, 0.00503, 0.00537, 0.00572, 0.00615, 0.00667, 0.00735,
        0.00822, 0.00927, 0.01041, 0.01164, 0.01286, 0.01408, 0.01537, 0.01688,
        0.01871, 0.02101, 0.02386, 0.02724, 0.03107, 0.03528, 0.03979, 0.04458,
        0.0498, 0.05569, 0.06245, 0.0703, 0.07937, 0.08941, 0.10038, 0.11205,
        0.12446, 0.13743, 0.15112, 0.16544, 0.18062, 0.19699, 0.2152, 0.23652,
        0.26338, 0.30101, 0.35966, 0.46234, 0.64743,
    ]; // Female nonsmoker
    const femaleSmokerMortalityArray = [
        0.00042, 0.00046, 0.0005, 0.00055, 0.00058, 0.00059, 0.0006, 0.00062,
        0.00063, 0.00065, 0.00066, 0.00069, 0.00072, 0.00074, 0.00078, 0.00083,
        0.00087, 0.00092, 0.00097, 0.00105, 0.00111, 0.00123, 0.00139, 0.00157,
        0.00178, 0.00202, 0.00231, 0.00258, 0.00286, 0.00314, 0.00342, 0.00372,
        0.00403, 0.00434, 0.00468, 0.00508, 0.00548, 0.00593, 0.00646, 0.007,
        0.00757, 0.00813, 0.00865, 0.00913, 0.00961, 0.01015, 0.01087, 0.01176,
        0.01299, 0.01437, 0.01593, 0.01746, 0.01903, 0.02042, 0.02198, 0.02363,
        0.02582, 0.02857, 0.03197, 0.03596, 0.04039, 0.04516, 0.05014, 0.05528,
        0.06076, 0.06683, 0.07369, 0.08155, 0.09048, 0.10103, 0.11142, 0.12326,
        0.13442, 0.14705, 0.15868, 0.17206, 0.18604, 0.20093, 0.21735, 0.23652,
        0.26338, 0.30101, 0.35966, 0.46234, 0.64743,
    ];
    const maleNonsmokerMortalityArray = [
        0.00073, 0.00086, 0.00096, 0.00101, 0.00105, 0.00106, 0.00104, 0.001,
        0.00095, 0.0009, 0.00083, 0.00077, 0.00073, 0.00069, 0.00067, 0.00065,
        0.00065, 0.00066, 0.00068, 0.00071, 0.00076, 0.00081, 0.00089, 0.00097,
        0.00107, 0.00118, 0.00131, 0.00145, 0.00161, 0.00177, 0.00196, 0.00217,
        0.0024, 0.00264, 0.00291, 0.00321, 0.00356, 0.00398, 0.00446, 0.00501,
        0.00563, 0.00632, 0.00706, 0.00785, 0.00875, 0.00976, 0.01089, 0.01218,
        0.01367, 0.01536, 0.01723, 0.01925, 0.02143, 0.02376, 0.02631, 0.02919,
        0.03247, 0.03629, 0.04069, 0.04565, 0.05096, 0.05661, 0.06252, 0.06861,
        0.07506, 0.08211, 0.08998, 0.09888, 0.10894, 0.11994, 0.13158, 0.14361,
        0.15587, 0.16806, 0.18033, 0.1928, 0.20561, 0.21907, 0.2336, 0.25072,
        0.27302, 0.30992, 0.36746, 0.4708, 0.6567,
    ];
    const maleSmokerMortalityArray = [
        0.00109, 0.0013, 0.00147, 0.00157, 0.00165, 0.00169, 0.0017, 0.00166,
        0.0016, 0.00154, 0.00145, 0.00137, 0.00133, 0.00129, 0.00129, 0.00131,
        0.00135, 0.0014, 0.00148, 0.00158, 0.0017, 0.00185, 0.00205, 0.00227,
        0.00253, 0.00283, 0.00318, 0.00355, 0.00397, 0.00441, 0.00491, 0.00541,
        0.00596, 0.00653, 0.00717, 0.00786, 0.00865, 0.00954, 0.01057, 0.01172,
        0.01295, 0.01428, 0.01566, 0.01712, 0.01863, 0.02031, 0.02221, 0.02435,
        0.02679, 0.02948, 0.03239, 0.03542, 0.03858, 0.04181, 0.04525, 0.04904,
        0.05325, 0.05806, 0.06348, 0.06939, 0.07593, 0.08265, 0.0894, 0.09605,
        0.10283, 0.11003, 0.11787, 0.12656, 0.13618, 0.14632, 0.15658, 0.16659,
        0.17614, 0.18654, 0.19656, 0.2063, 0.21589, 0.22565, 0.23827, 0.25322,
        0.27302, 0.30992, 0.36746, 0.4708, 0.6567,
    ];
    // Step 2: Construct an array of n length where each value is payment
    for (let i = 0; i < payPeriods; i++) {
        paymentArray.push(payment);
    }
    // Step 3: Calculate the Actuarial Present Value
    let actuarialPresentValue = 0;
    let mortalityArray = []; // initialize mortality array here to conditionally mutate later
    for (let i = 0; i < payPeriods; i++) {
        // Determine the correct mortality array based on gender and smoking status
        if (gender === "female" && smokingStatus === "non-smoker") {
            mortalityArray = femaleNonsmokerMortalityArray;
        }
        else if (gender === "female" && smokingStatus === "smoker") {
            mortalityArray = femaleSmokerMortalityArray;
        }
        else if (gender === "male" && smokingStatus === "non-smoker") {
            mortalityArray = maleNonsmokerMortalityArray;
        }
        else if (gender === "male" && smokingStatus === "smoker") {
            mortalityArray = maleSmokerMortalityArray;
        }
        else {
            throw new Error("Invalid gender or smoking status");
        }
        const presentValue = paymentArray[i] *
            discountRateArray[i] *
            (1 - mortalityArray[i + age - 15]);
        // Add it to the total
        actuarialPresentValue += presentValue;
    }
    console.log("fit check", actuarialPresentValue, discountRateArray, paymentArray);
    return actuarialPresentValue;
};
// Example usage:
// const result = ActuarialCalculation(0.05, 10, "Male", 1000, "Smoker", 30);
// console.log(result); // Replace with how you want to use the result
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ActuarialCalculation);


/***/ }),

/***/ "./src/popup/index.tsx":
/*!*****************************!*\
  !*** ./src/popup/index.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom/client */ "./node_modules/react-dom/client.js");
/* harmony import */ var _assets_tailwind_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../assets/tailwind.css */ "./src/assets/tailwind.css");
/* harmony import */ var _popup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./popup */ "./src/popup/popup.tsx");




function init() {
    const appContainer = document.createElement("div");
    document.body.appendChild(appContainer);
    if (!appContainer) {
        throw new Error("Can not find AppContainer");
    }
    const root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__.createRoot)(appContainer);
    console.log(appContainer);
    root.render(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_popup__WEBPACK_IMPORTED_MODULE_3__["default"], null));
}
init();


/***/ }),

/***/ "./src/popup/popup.tsx":
/*!*****************************!*\
  !*** ./src/popup/popup.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _popup_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./popup.css */ "./src/popup/popup.css");
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-spring */ "./node_modules/react-spring/dist/react-spring.modern.mjs");
/* harmony import */ var _calculations_ActuarialCalculation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../calculations/ActuarialCalculation */ "./src/calculations/ActuarialCalculation.ts");




const Popup = () => {
    const Stages = {
        Input: 1,
        Result: 2,
    };
    // State for dropdown selections
    const [gender, setGender] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [smoking, setSmoking] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [periods, setPeriods] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("0");
    const [interestRate, setInterestRate] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("%");
    const [numericInterest, setNumericInterest] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const [paymentAmount, setPaymentAmount] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("$");
    const [paymentFrequency, setPaymentFrequency] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("monthly");
    const [paymentStartYear, setPaymentStartYear] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("0");
    const [stage, setStage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(Stages.Input);
    const [result, setResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null); // Result state
    const [age, setAge] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(15);
    const [ageError, setAgeError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [payPeriodError, setPayPeriodError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [smokingStatusError, setSmokingStatusError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [genderStatusError, setGenderStatusError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [formattedResult, setFormattedResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [disableButton, setDisableButton] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    // Function to format the interest rate input
    const reformatInterestRateInput = (value) => {
        // Remove any non-digit characters (except ".")
        value = value.replace(/[^\d.]/g, "");
        // Ensure only one decimal point
        const parts = value.split(".");
        if (parts.length > 2) {
            value = parts.slice(0, 2).join(".") + parts.slice(2).join("");
        }
        return value;
    };
    function parseCurrencyString(currencyString) {
        // Remove special characters ('$' and ',') from the input string
        const sanitizedString = currencyString.replace(/[$,]/g, "");
        // Parse the sanitized string into a number
        const numberValue = parseFloat(sanitizedString);
        return numberValue;
    }
    const formatResult = (value) => {
        // Check if the value is not a number or is NaN
        if (isNaN(value) || typeof value !== "number") {
            return "$0.00";
        }
        // Convert the number to a string and round it to two decimal places
        const formattedValue = value.toFixed(2);
        // Split the formatted string into dollars and cents parts
        const [dollars, cents] = formattedValue.split(".");
        // Add commas for thousands in the dollars part
        const formattedDollars = dollars.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        // Reconstruct the formatted value with dollars and cents
        return `$${formattedDollars}.${cents}`;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!ageError && !payPeriodError) {
            const result = (0,_calculations_ActuarialCalculation__WEBPACK_IMPORTED_MODULE_3__["default"])(numericInterest / 100, // Use the parsed interest rate
            parseInt(periods), gender, parseCurrencyString(paymentAmount), smoking, age);
            setResult(result);
            setFormattedResult(formatResult(result));
        }
        if (gender !== "") {
            setGenderStatusError(false);
            setDisableButton(false);
        }
        if (age > 15 && age < 100) {
            setAgeError(false);
        }
        if (smoking !== "") {
            setSmokingStatusError(false);
            setDisableButton(false);
        }
    });
    // Function to handle the calculation when the button is clicked
    const handleCalculate = () => {
        if (smoking == "") {
            setSmokingStatusError(true);
            return;
        }
        if (gender == "") {
            setGenderStatusError(true);
            return;
        }
        // Check for age < 15
        if (age < 15 || age > 100) {
            setAgeError(true);
            return;
        }
        else {
            // Check for payPeriod + age <= 100
            if (parseInt(periods) + age > 100) {
                setPayPeriodError(true);
                return;
            }
            else {
                setPayPeriodError(false);
                setAgeError(false);
            }
        }
        if (!ageError &&
            !payPeriodError &&
            !genderStatusError &&
            !smokingStatusError) {
            setNumericInterest(parseFloat(interestRate.replace(/%/g, "")));
            const result = (0,_calculations_ActuarialCalculation__WEBPACK_IMPORTED_MODULE_3__["default"])(numericInterest / 100, // Use the parsed interest rate
            parseInt(periods), gender, parseCurrencyString(paymentAmount), smoking, age);
            setResult(result);
            setFormattedResult(formatResult(result));
        }
        console.log("handle calc", ageError, genderStatusError, smokingStatusError, payPeriodError);
        if (ageError || genderStatusError || smokingStatusError || payPeriodError) {
            return;
        }
        else {
            setStage(Stages.Result);
        }
    };
    // Function to handle going back to the input stage
    const handleBackToStage1 = () => {
        setStage(Stages.Input); // Move back to the input stage
    };
    // Function to format the interest rate input
    const formatInterestRateInput = (value) => {
        // Remove any existing percent symbols from the value
        value = value.replace(/%/g, "");
        // Add a percent symbol only if the last character is not already a percent symbol
        if (value[value.length - 1] !== "%") {
            value += "%";
        }
        return value;
    };
    // Function to format the payment amount input
    const formatPaymentAmountInput = (value) => {
        // Remove any existing dollar signs and commas from the value
        value = value.replace(/[$,]/g, "");
        // Split the value into dollars and cents (if present)
        const [dollars, cents] = value.split(".");
        // Add commas for thousands in the dollars part
        const formattedDollars = dollars.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        // Reconstruct the formatted value with dollars and cents
        if (cents !== undefined) {
            return "$" + formattedDollars + "." + cents;
        }
        else {
            return "$" + formattedDollars;
        }
    };
    // Stage 1: Input Fields
    const stage1 = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "mb-4 " },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "block text-gray-900 font-bold mb-2" }, "Gender"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "flex items-center" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: "border rounded px-3 py-2 w-full", value: gender, onChange: (e) => setGender(e.target.value), onSelect: (e) => setGenderStatusError(false) },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "" }, "Select Gender"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "male" }, "Male"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "female" }, "Female")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "ml-4 text-gray-900 font-bold mb-2" }, "Age"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "number", className: "border rounded px-3 py-2 w-full", value: age, onSelect: (e) => setAgeError(false), onChange: (e) => {
                        setAge(parseInt(e.target.value));
                    }, min: 15, max: 100 })),
            genderStatusError && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "text-green-500 text-left pr-4" }, "Please select a gender.")),
            ageError && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "text-green-500 text-left pr-4" }, "Age must be between 15 and 100."))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "mb-4" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "block text-gray-700 font-bold mb-2" }, "Smoking Status"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: "border rounded px-3 py-2 w-full", value: smoking, onChange: (e) => setSmoking(e.target.value), onSelect: (e) => setSmokingStatusError(false) },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "" }, "Select Smoking Status"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "smoker" }, "Smoker"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "non-smoker" }, "Non-Smoker"))),
            smokingStatusError && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "text-green-500 text-left pr-4" }, "Please select a smoking status."))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "mb-4" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "block text-gray-700 font-bold mb-2" }, "Number of Pay Periods"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "number", className: "border rounded px-3 py-2 w-full", value: periods, onSelect: (e) => {
                    setPeriods("");
                    setPayPeriodError(false);
                }, onChange: (e) => {
                    setPeriods(e.target.value);
                    if (payPeriodError) {
                        setPayPeriodError(false);
                    }
                }, min: 0, max: 85 }),
            payPeriodError && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "text-green-500 text-right pr-4" }, "The sum of Pay Periods and Age must not exceed 100."))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "mb-4" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "block text-gray-700 font-bold mb-2" }, "Interest Rate"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "border rounded px-3 py-2 w-full", value: interestRate, onChange: (e) => setInterestRate(formatInterestRateInput(e.target.value)), onKeyDown: (e) => {
                    // Check if the pressed key is the backspace key
                    if (e.key === "Backspace") {
                        // Handle backspace key here (if needed)
                        setInterestRate("");
                    }
                } })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "mb-4" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "block text-gray-700 font-bold mb-2" }, "Payment Amount"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "border rounded px-3 py-2 w-full", value: paymentAmount, onChange: (e) => setPaymentAmount(formatPaymentAmountInput(e.target.value)) })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 mt-4", onClick: handleCalculate, hidden: disableButton }, "Calculate")));
    // Stage 2: Result
    const stage2 = (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "text-center h-full space-y-12  " },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "text-xl mb-4 " },
            "The Actuarial Present Value of that series of payments is:",
            " ",
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "text-green-600 font-bold text-3xl" }, formattedResult || "0")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "py-32" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "bg-blue-500 text-white px-4 py-4 rounded hover:bg-blue-600 ", onClick: handleBackToStage1 }, "Back to Input"))));
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "w-full p-4 bg-gray-200" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", { className: `text-2xl mb-4  ${stage === Stages.Input ? "text-green-500 font-bold " : "text-blue-500"} flex justify-center` }, stage === Stages.Input ? "Actuarial Present Value" : "Result"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spring__WEBPACK_IMPORTED_MODULE_2__.animated.div, { style: { width: "100%", height: "100%" } }, stage === Stages.Input ? stage1 : stage2)));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Popup);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"popup": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkreactjs_chrome"] = self["webpackChunkreactjs_chrome"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendors-node_modules_css-loader_dist_runtime_api_js-node_modules_css-loader_dist_runtime_sour-b53f7e","vendors-node_modules_react-spring_dist_react-spring_modern_mjs","src_assets_tailwind_css"], () => (__webpack_require__("./src/popup/index.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=popup.js.map